from django.apps import AppConfig


class PersonalPlatformConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'personal_platform'
