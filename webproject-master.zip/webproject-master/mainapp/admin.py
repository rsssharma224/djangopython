from django.contrib import admin
from mainapp import models

admin.site.register(models.Data)
